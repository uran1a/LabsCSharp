using lab6_winform.Classes;
namespace lab6_winform
{
    public partial class Form1 : Form
    {
        List<Build> builds = new();
        List<Build> addBuilds;

        List<Object> objects = new();
        List<Object> addObjects;

        Stack<string> stack = new();
        public Form1()
        {
            InitializeComponent();

            Build b1 = new("���� ������", "������������ 1");
            Build b2 = new("���������� ��������", "���������� �������� 129/1");
            Build b3 = new("������� ������", "����������� 35");
            addBuilds = new(){ b1, b2, b3 };

            addObjects = new() { b1, b2, b3 };

            listViewTask1.View = View.Details;
            listViewTask1.Columns.Clear();
            listViewTask1.Columns.Add("ID", 30);
            listViewTask1.Columns.Add("��������", 150);
            listViewTask1.Columns.Add("�����",150);
            listViewTask1.FullRowSelect = true;

            listViewTask2.View = View.Details;
            listViewTask2.Columns.Clear();
            listViewTask2.Columns.Add("ID", 30);
            listViewTask2.Columns.Add("��������", 150);
            listViewTask2.Columns.Add("�����", 150);
            listViewTask2.FullRowSelect = true;

            ReloadCheckedList();
        }
        private void ReloadCheckedList()
        {
            checkedListBoxTask1.Items.Clear();
            foreach (Build build in addBuilds)
                checkedListBoxTask1.Items.Add(build.ToString());

            checkedListBoxTask2.Items.Clear();
            foreach (Build build in addObjects)
                checkedListBoxTask2.Items.Add(build.ToString());
        }

        private void ReloadListView()
        {
            listViewTask1.Items.Clear();
            for(int i = 0; i < builds.Count; i++)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(i + 1));
                ListViewItem.ListViewSubItem title = new(item, builds[i].Title);
                ListViewItem.ListViewSubItem address = new(item, builds[i].Address);
                item.SubItems.Add(title);
                item.SubItems.Add(address);
                listViewTask1.Items.Add(item);
            }

            listViewTask2.Items.Clear();
            for (int i = 0; i < objects.Count; i++)
            {
                ListViewItem item = new ListViewItem(Convert.ToString(i + 1));
                Build temp = (Build)objects[i];
                ListViewItem.ListViewSubItem title = new(item, temp.Title);
                ListViewItem.ListViewSubItem address = new(item, temp.Address);
                item.SubItems.Add(title);
                item.SubItems.Add(address);
                listViewTask2.Items.Add(item);
            }
        }

        private void buttonAddTask1_Click(object sender, EventArgs e)
        {
            if (checkedListBoxTask1.CheckedItems.Count == 0) return;
            for (int i = 0; i < checkedListBoxTask1.CheckedItems.Count; i++)
                for (int j = 0; j < addBuilds.Count; j++)
                    if (checkedListBoxTask1.CheckedItems[i].ToString() == addBuilds[j].ToString())
                    {
                        builds.Add(addBuilds[j]);
                        addBuilds.RemoveAt(j);
                    }
            ReloadCheckedList();
            ReloadListView();
        }

        private void buttonInsertTask1_Click(object sender, EventArgs e)
        {
            try
            {
                if (checkedListBoxTask1.CheckedItems.Count == 0) throw new Exception("�������� ���!");
                for (int i = 0; i < checkedListBoxTask1.CheckedItems.Count; i++)
                    for (int j = 0; j < addBuilds.Count; j++)
                        if (checkedListBoxTask1.CheckedItems[i].ToString() == addBuilds[j].ToString())
                        {
                            int index = Convert.ToInt32(textBoxTask1.Text);
                            textBoxTask1.Clear();
                            if (index < builds.Count || index < 0) throw new Exception("�������� ������!");
                            builds.Insert(index, addBuilds[j]);
                            addBuilds.RemoveAt(j);
                        }
                ReloadCheckedList();
                ReloadListView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonSortTask1_Click(object sender, EventArgs e)
        {
            builds.Sort();
            ReloadListView();
        }

        private void buttonRemoveTask1_Click(object sender, EventArgs e)
        {
            int index = Convert.ToInt32(listViewTask1.FocusedItem.SubItems[0].Text) - 1;
            builds.RemoveAt(index);
            ReloadListView();
        }

        private void buttonClearTask1_Click(object sender, EventArgs e)
        {
            builds.Clear();
            ReloadListView();
        }
        private void ReloadStack()
        {
            string stackText = "";
            foreach (string s in stack)
            {
                stackText += (s + Environment.NewLine);
            }
            textBoxStack.Text = stackText;
        }

        private void buttonPush_Click(object sender, EventArgs e)
        {
            stack.Push(textBoxPush.Text);
            textBoxPush.Clear();
            ReloadStack();
        }

        private void buttonPop_Click(object sender, EventArgs e)
        {
            textBoxPop.Text = stack.Pop();
            ReloadStack();
        }
        //task 2.
        private void buttonAddTask2_Click(object sender, EventArgs e)
        {
            if (checkedListBoxTask2.CheckedItems.Count == 0) return;
            for (int i = 0; i < checkedListBoxTask2.CheckedItems.Count; i++)
                for (int j = 0; j < addObjects.Count; j++)
                    if (checkedListBoxTask2.CheckedItems[i].ToString() == addObjects[j].ToString())
                    {
                        objects.Add(addObjects[j]);
                        addObjects.RemoveAt(j);
                    }
            ReloadCheckedList();
            ReloadListView();
        }

        private void buttonSortTask2_Click(object sender, EventArgs e)
        {
            objects.Sort();
            ReloadListView();
        }

        private void buttonInsertTask2_Click(object sender, EventArgs e)
        {
            try
            {
                if (checkedListBoxTask2.CheckedItems.Count == 0) throw new Exception("�������� ���!");
                for (int i = 0; i < checkedListBoxTask2.CheckedItems.Count; i++)
                    for (int j = 0; j < addObjects.Count; j++)
                        if (checkedListBoxTask2.CheckedItems[i].ToString() == addObjects[j].ToString())
                        {
                            int index = Convert.ToInt32(textBoxTask2.Text);
                            textBoxTask2.Clear();
                            if (index < objects.Count || index < 0) throw new Exception("�������� ������!");
                            objects.Insert(index, addObjects[j]);
                            addObjects.RemoveAt(j);
                        }
                ReloadCheckedList();
                ReloadListView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBoxTask2_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonRemoveTask2_Click(object sender, EventArgs e)
        {
            int index = Convert.ToInt32(listViewTask2.FocusedItem.SubItems[0].Text) - 1;
            objects.RemoveAt(index);
            ReloadListView();
        }

        private void buttonClearTask2_Click(object sender, EventArgs e)
        {
            objects.Clear();
            ReloadListView();
        }
        
        

}
}
namespace lab5_winform
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonComputationTask2_Click(object sender, EventArgs e)
        {
            try{
                if (textBoxTask2.Text == "") throw new Exception("������� �����!");
                String[] words = textBoxTask2.Text.Split(" ");
                String line = "";
                for(int i = 0; i < words.Length; i++)
                {
                    words[i] = words[i].TrimStart(words[i][0]);
                    words[i] = words[i].TrimEnd(words[i][words[i].Length-1]);
                    line += words[i] + " ";
                }

                labelResultTask2.Text = line;
            } 
            catch ( Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonTask1_Click(object sender, EventArgs e)
        {
            string str = textBoxTask1.Text;
            char[] a = str.ToCharArray();
            char temp = a[0];
            a[0] = a[a.Length-1];
            a[a.Length-1] = temp;
            str = new string(a);
            textBoxTask1.Text = str;
        }

        private void buttonTask3_Click(object sender, EventArgs e)
        {
            string str = textBoxTask3.Text;
            textBoxTask3.Text = str.ToLower();
        }
    }
}
﻿namespace lab3_winform
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBoxEps = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.labelResult5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonResult5 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.labelResult6 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonCalculation6 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.labelResultElse = new System.Windows.Forms.Label();
            this.labelTask7_sum3 = new System.Windows.Forms.Label();
            this.textBoxTask7 = new System.Windows.Forms.TextBox();
            this.labelResult7_sum3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelTask7_sum2 = new System.Windows.Forms.Label();
            this.buttonTask7 = new System.Windows.Forms.Button();
            this.labelResult7_sum2 = new System.Windows.Forms.Label();
            this.labelTask7_sum1 = new System.Windows.Forms.Label();
            this.labelResult7_sum1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.labelResult8 = new System.Windows.Forms.Label();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonResult8 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(803, 451);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBoxEps);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.labelResult5);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.buttonResult5);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(795, 418);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Задание 5";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBoxEps
            // 
            this.textBoxEps.Location = new System.Drawing.Point(8, 43);
            this.textBoxEps.Name = "textBoxEps";
            this.textBoxEps.Size = new System.Drawing.Size(125, 27);
            this.textBoxEps.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(8, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(264, 28);
            this.label4.TabIndex = 12;
            this.label4.Text = "Сумма бесконечного ряда: ";
            // 
            // labelResult5
            // 
            this.labelResult5.AutoSize = true;
            this.labelResult5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResult5.Location = new System.Drawing.Point(272, 86);
            this.labelResult5.Name = "labelResult5";
            this.labelResult5.Size = new System.Drawing.Size(0, 28);
            this.labelResult5.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(8, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(195, 28);
            this.label7.TabIndex = 8;
            this.label7.Text = "Введите предел eps:";
            // 
            // buttonResult5
            // 
            this.buttonResult5.Location = new System.Drawing.Point(10, 125);
            this.buttonResult5.Name = "buttonResult5";
            this.buttonResult5.Size = new System.Drawing.Size(152, 44);
            this.buttonResult5.TabIndex = 7;
            this.buttonResult5.Text = "Найти сумму";
            this.buttonResult5.UseVisualStyleBackColor = true;
            this.buttonResult5.Click += new System.EventHandler(this.buttonResult5_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.labelResult6);
            this.tabPage2.Controls.Add(this.numericUpDown2);
            this.tabPage2.Controls.Add(this.numericUpDown1);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.buttonCalculation6);
            this.tabPage2.Controls.Add(this.pictureBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(795, 418);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Задание 6";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(8, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(292, 28);
            this.label2.TabIndex = 5;
            this.label2.Text = "Сумма полученных значений: ";
            // 
            // labelResult6
            // 
            this.labelResult6.AutoSize = true;
            this.labelResult6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResult6.Location = new System.Drawing.Point(300, 147);
            this.labelResult6.Name = "labelResult6";
            this.labelResult6.Size = new System.Drawing.Size(0, 28);
            this.labelResult6.TabIndex = 3;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(166, 104);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(150, 27);
            this.numericUpDown2.TabIndex = 4;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(10, 104);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(150, 27);
            this.numericUpDown1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(8, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(300, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "Введите отрезок (1-ое < 2-ого):";
            // 
            // buttonCalculation6
            // 
            this.buttonCalculation6.Location = new System.Drawing.Point(10, 188);
            this.buttonCalculation6.Name = "buttonCalculation6";
            this.buttonCalculation6.Size = new System.Drawing.Size(152, 44);
            this.buttonCalculation6.TabIndex = 1;
            this.buttonCalculation6.Text = "Найти сумму";
            this.buttonCalculation6.UseVisualStyleBackColor = true;
            this.buttonCalculation6.Click += new System.EventHandler(this.buttonCalculation6_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::lab3_winform.Properties.Resources.Screenshot_3;
            this.pictureBox1.Location = new System.Drawing.Point(8, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(540, 57);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.labelResultElse);
            this.tabPage3.Controls.Add(this.labelTask7_sum3);
            this.tabPage3.Controls.Add(this.textBoxTask7);
            this.tabPage3.Controls.Add(this.labelResult7_sum3);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.labelTask7_sum2);
            this.tabPage3.Controls.Add(this.buttonTask7);
            this.tabPage3.Controls.Add(this.labelResult7_sum2);
            this.tabPage3.Controls.Add(this.labelTask7_sum1);
            this.tabPage3.Controls.Add(this.labelResult7_sum1);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(795, 418);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Задание 7";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // labelResultElse
            // 
            this.labelResultElse.AutoSize = true;
            this.labelResultElse.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResultElse.Location = new System.Drawing.Point(15, 274);
            this.labelResultElse.Name = "labelResultElse";
            this.labelResultElse.Size = new System.Drawing.Size(424, 28);
            this.labelResultElse.TabIndex = 24;
            this.labelResultElse.Text = "Все комбинации суммы цифр больше сотен!";
            this.labelResultElse.Visible = false;
            // 
            // labelTask7_sum3
            // 
            this.labelTask7_sum3.AutoSize = true;
            this.labelTask7_sum3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelTask7_sum3.Location = new System.Drawing.Point(15, 227);
            this.labelTask7_sum3.Name = "labelTask7_sum3";
            this.labelTask7_sum3.Size = new System.Drawing.Size(228, 28);
            this.labelTask7_sum3.TabIndex = 22;
            this.labelTask7_sum3.Text = "Третичная сумма цифр:";
            this.labelTask7_sum3.Visible = false;
            // 
            // textBoxTask7
            // 
            this.textBoxTask7.Location = new System.Drawing.Point(315, 42);
            this.textBoxTask7.Name = "textBoxTask7";
            this.textBoxTask7.Size = new System.Drawing.Size(125, 27);
            this.textBoxTask7.TabIndex = 19;
            // 
            // labelResult7_sum3
            // 
            this.labelResult7_sum3.AutoSize = true;
            this.labelResult7_sum3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResult7_sum3.Location = new System.Drawing.Point(261, 227);
            this.labelResult7_sum3.Name = "labelResult7_sum3";
            this.labelResult7_sum3.Size = new System.Drawing.Size(0, 28);
            this.labelResult7_sum3.TabIndex = 21;
            this.labelResult7_sum3.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(8, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(646, 56);
            this.label9.TabIndex = 16;
            this.label9.Text = "В натуральном числе, найти сумму цифр, которые меньше его сотен.\r\nВведите четырёх" +
    "значное число:";
            // 
            // labelTask7_sum2
            // 
            this.labelTask7_sum2.AutoSize = true;
            this.labelTask7_sum2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelTask7_sum2.Location = new System.Drawing.Point(15, 184);
            this.labelTask7_sum2.Name = "labelTask7_sum2";
            this.labelTask7_sum2.Size = new System.Drawing.Size(231, 28);
            this.labelTask7_sum2.TabIndex = 20;
            this.labelTask7_sum2.Text = "Вторичная сумма цифр:";
            this.labelTask7_sum2.Visible = false;
            // 
            // buttonTask7
            // 
            this.buttonTask7.Location = new System.Drawing.Point(15, 80);
            this.buttonTask7.Name = "buttonTask7";
            this.buttonTask7.Size = new System.Drawing.Size(152, 44);
            this.buttonTask7.TabIndex = 15;
            this.buttonTask7.Text = "Найти сумму";
            this.buttonTask7.UseVisualStyleBackColor = true;
            this.buttonTask7.Click += new System.EventHandler(this.buttonTask7_Click);
            // 
            // labelResult7_sum2
            // 
            this.labelResult7_sum2.AutoSize = true;
            this.labelResult7_sum2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResult7_sum2.Location = new System.Drawing.Point(261, 184);
            this.labelResult7_sum2.Name = "labelResult7_sum2";
            this.labelResult7_sum2.Size = new System.Drawing.Size(0, 28);
            this.labelResult7_sum2.TabIndex = 19;
            this.labelResult7_sum2.Visible = false;
            // 
            // labelTask7_sum1
            // 
            this.labelTask7_sum1.AutoSize = true;
            this.labelTask7_sum1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelTask7_sum1.Location = new System.Drawing.Point(15, 138);
            this.labelTask7_sum1.Name = "labelTask7_sum1";
            this.labelTask7_sum1.Size = new System.Drawing.Size(240, 28);
            this.labelTask7_sum1.TabIndex = 18;
            this.labelTask7_sum1.Text = "Первичная сумма цифр: ";
            this.labelTask7_sum1.Visible = false;
            // 
            // labelResult7_sum1
            // 
            this.labelResult7_sum1.AutoSize = true;
            this.labelResult7_sum1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResult7_sum1.Location = new System.Drawing.Point(261, 138);
            this.labelResult7_sum1.Name = "labelResult7_sum1";
            this.labelResult7_sum1.Size = new System.Drawing.Size(0, 28);
            this.labelResult7_sum1.TabIndex = 17;
            this.labelResult7_sum1.Visible = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.labelResult8);
            this.tabPage4.Controls.Add(this.numericUpDown4);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.buttonResult8);
            this.tabPage4.Controls.Add(this.pictureBox2);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(795, 418);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Задание 8";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(8, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 28);
            this.label3.TabIndex = 12;
            this.label3.Text = "Сумма: ";
            // 
            // labelResult8
            // 
            this.labelResult8.AutoSize = true;
            this.labelResult8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResult8.Location = new System.Drawing.Point(95, 117);
            this.labelResult8.Name = "labelResult8";
            this.labelResult8.Size = new System.Drawing.Size(64, 28);
            this.labelResult8.TabIndex = 9;
            this.labelResult8.Text = "adasd";
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(123, 81);
            this.numericUpDown4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(150, 27);
            this.numericUpDown4.TabIndex = 10;
            this.numericUpDown4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(8, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 28);
            this.label5.TabIndex = 8;
            this.label5.Text = "Введите N:";
            // 
            // buttonResult8
            // 
            this.buttonResult8.Location = new System.Drawing.Point(8, 157);
            this.buttonResult8.Name = "buttonResult8";
            this.buttonResult8.Size = new System.Drawing.Size(152, 44);
            this.buttonResult8.TabIndex = 7;
            this.buttonResult8.Text = "Найти сумму";
            this.buttonResult8.UseVisualStyleBackColor = true;
            this.buttonResult8.Click += new System.EventHandler(this.buttonResult8_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(687, 67);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private PictureBox pictureBox1;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private Button buttonCalculation6;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown1;
        private Label label1;
        private Label labelResult6;
        private Label label2;
        private Label label3;
        private Label labelResult8;
        private NumericUpDown numericUpDown4;
        private Label label5;
        private Button buttonResult8;
        private PictureBox pictureBox2;
        private Label label4;
        private Label labelResult5;
        private Label label7;
        private Button buttonResult5;
        private TextBox textBoxEps;
        private TextBox textBoxTask7;
        private Label labelTask7_sum1;
        private Label labelResult7_sum1;
        private Label label9;
        private Button buttonTask7;
        private Label labelResultElse;
        private Label labelTask7_sum3;
        private Label labelResult7_sum3;
        private Label labelTask7_sum2;
        private Label labelResult7_sum2;
    }
}
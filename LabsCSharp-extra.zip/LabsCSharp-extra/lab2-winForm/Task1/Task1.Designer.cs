﻿namespace lab2_winForm_Task1
{
    partial class Task1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panelResultSubtask1 = new System.Windows.Forms.Panel();
            this.labelResultB = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.labelResultA = new System.Windows.Forms.Label();
            this.textBoxY = new System.Windows.Forms.TextBox();
            this.textBoxZ = new System.Windows.Forms.TextBox();
            this.textBoxX = new System.Windows.Forms.TextBox();
            this.buttonСalculation1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panelResultSubtask2 = new System.Windows.Forms.Panel();
            this.labelResultRadius = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.buttonСalculation = new System.Windows.Forms.Button();
            this.textBoxX3Y3 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxX2Y2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxX1Y1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panelResultSubtask3 = new System.Windows.Forms.Panel();
            this.labelResultEquals = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.buttonСalculation3 = new System.Windows.Forms.Button();
            this.textBoxNumber2 = new System.Windows.Forms.TextBox();
            this.textBoxNumber1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.labelResultTime = new System.Windows.Forms.Label();
            this.textBoxTime = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.buttonResultSubtask4 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panelResultSubtask1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panelResultSubtask2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panelResultSubtask3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(1, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(642, 354);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panelResultSubtask1);
            this.tabPage1.Controls.Add(this.textBoxY);
            this.tabPage1.Controls.Add(this.textBoxZ);
            this.tabPage1.Controls.Add(this.textBoxX);
            this.tabPage1.Controls.Add(this.buttonСalculation1);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(634, 321);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Задание 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panelResultSubtask1
            // 
            this.panelResultSubtask1.Controls.Add(this.labelResultB);
            this.panelResultSubtask1.Controls.Add(this.label7);
            this.panelResultSubtask1.Controls.Add(this.labelResultA);
            this.panelResultSubtask1.Location = new System.Drawing.Point(178, 125);
            this.panelResultSubtask1.Name = "panelResultSubtask1";
            this.panelResultSubtask1.Size = new System.Drawing.Size(298, 189);
            this.panelResultSubtask1.TabIndex = 9;
            this.panelResultSubtask1.Visible = false;
            // 
            // labelResultB
            // 
            this.labelResultB.AutoSize = true;
            this.labelResultB.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResultB.Location = new System.Drawing.Point(3, 71);
            this.labelResultB.Name = "labelResultB";
            this.labelResultB.Size = new System.Drawing.Size(23, 28);
            this.labelResultB.TabIndex = 12;
            this.labelResultB.Text = "Y";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(3, 1);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 28);
            this.label7.TabIndex = 10;
            this.label7.Text = "Результат:";
            // 
            // labelResultA
            // 
            this.labelResultA.AutoSize = true;
            this.labelResultA.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResultA.Location = new System.Drawing.Point(3, 34);
            this.labelResultA.Name = "labelResultA";
            this.labelResultA.Size = new System.Drawing.Size(24, 28);
            this.labelResultA.TabIndex = 11;
            this.labelResultA.Text = "X";
            // 
            // textBoxY
            // 
            this.textBoxY.Location = new System.Drawing.Point(34, 197);
            this.textBoxY.Name = "textBoxY";
            this.textBoxY.Size = new System.Drawing.Size(125, 27);
            this.textBoxY.TabIndex = 7;
            // 
            // textBoxZ
            // 
            this.textBoxZ.Location = new System.Drawing.Point(34, 234);
            this.textBoxZ.Name = "textBoxZ";
            this.textBoxZ.Size = new System.Drawing.Size(125, 27);
            this.textBoxZ.TabIndex = 8;
            // 
            // textBoxX
            // 
            this.textBoxX.Location = new System.Drawing.Point(34, 163);
            this.textBoxX.Name = "textBoxX";
            this.textBoxX.Size = new System.Drawing.Size(125, 27);
            this.textBoxX.TabIndex = 6;
            // 
            // buttonСalculation1
            // 
            this.buttonСalculation1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonСalculation1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonСalculation1.Location = new System.Drawing.Point(6, 271);
            this.buttonСalculation1.Name = "buttonСalculation1";
            this.buttonСalculation1.Size = new System.Drawing.Size(139, 43);
            this.buttonСalculation1.TabIndex = 5;
            this.buttonСalculation1.Text = "Вычислить";
            this.buttonСalculation1.UseVisualStyleBackColor = false;
            this.buttonСalculation1.Click += new System.EventHandler(this.buttonСalculation_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(8, 234);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 28);
            this.label4.TabIndex = 4;
            this.label4.Text = "Z";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(7, 196);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Y";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(7, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 28);
            this.label2.TabIndex = 2;
            this.label2.Text = "X";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(7, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 28);
            this.label1.TabIndex = 1;
            this.label1.Text = "Введите:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::lab2_winForm.Properties.Resources.task1_subtask11;
            this.pictureBox1.Location = new System.Drawing.Point(3, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(624, 116);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panelResultSubtask2);
            this.tabPage2.Controls.Add(this.buttonСalculation);
            this.tabPage2.Controls.Add(this.textBoxX3Y3);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.textBoxX2Y2);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.textBoxX1Y1);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(634, 321);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Задание 2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panelResultSubtask2
            // 
            this.panelResultSubtask2.Controls.Add(this.labelResultRadius);
            this.panelResultSubtask2.Controls.Add(this.label10);
            this.panelResultSubtask2.Location = new System.Drawing.Point(3, 144);
            this.panelResultSubtask2.Name = "panelResultSubtask2";
            this.panelResultSubtask2.Size = new System.Drawing.Size(621, 125);
            this.panelResultSubtask2.TabIndex = 8;
            // 
            // labelResultRadius
            // 
            this.labelResultRadius.AutoSize = true;
            this.labelResultRadius.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResultRadius.Location = new System.Drawing.Point(4, 28);
            this.labelResultRadius.Name = "labelResultRadius";
            this.labelResultRadius.Size = new System.Drawing.Size(76, 28);
            this.labelResultRadius.TabIndex = 1;
            this.labelResultRadius.Text = "label11";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(604, 28);
            this.label10.TabIndex = 0;
            this.label10.Text = "Вычислить радиус окружности, описанной около треугольника:";
            // 
            // buttonСalculation
            // 
            this.buttonСalculation.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonСalculation.Location = new System.Drawing.Point(229, 45);
            this.buttonСalculation.Name = "buttonСalculation";
            this.buttonСalculation.Size = new System.Drawing.Size(139, 43);
            this.buttonСalculation.TabIndex = 7;
            this.buttonСalculation.Text = "Вычислить";
            this.buttonСalculation.UseVisualStyleBackColor = false;
            this.buttonСalculation.Click += new System.EventHandler(this.buttonCalculation_Click);
            // 
            // textBoxX3Y3
            // 
            this.textBoxX3Y3.Location = new System.Drawing.Point(70, 111);
            this.textBoxX3Y3.Name = "textBoxX3Y3";
            this.textBoxX3Y3.Size = new System.Drawing.Size(153, 27);
            this.textBoxX3Y3.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(3, 110);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 28);
            this.label9.TabIndex = 5;
            this.label9.Text = "x3, y3";
            // 
            // textBoxX2Y2
            // 
            this.textBoxX2Y2.Location = new System.Drawing.Point(70, 78);
            this.textBoxX2Y2.Name = "textBoxX2Y2";
            this.textBoxX2Y2.Size = new System.Drawing.Size(153, 27);
            this.textBoxX2Y2.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(3, 77);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 28);
            this.label8.TabIndex = 3;
            this.label8.Text = "x2, y2";
            // 
            // textBoxX1Y1
            // 
            this.textBoxX1Y1.Location = new System.Drawing.Point(71, 45);
            this.textBoxX1Y1.Name = "textBoxX1Y1";
            this.textBoxX1Y1.Size = new System.Drawing.Size(153, 27);
            this.textBoxX1Y1.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(3, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 28);
            this.label6.TabIndex = 1;
            this.label6.Text = "x1, y1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(0, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(415, 28);
            this.label5.TabIndex = 0;
            this.label5.Text = "Введите координаты вершин треугольника:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panelResultSubtask3);
            this.tabPage3.Controls.Add(this.buttonСalculation3);
            this.tabPage3.Controls.Add(this.textBoxNumber2);
            this.tabPage3.Controls.Add(this.textBoxNumber1);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(634, 321);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Задание 3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panelResultSubtask3
            // 
            this.panelResultSubtask3.Controls.Add(this.labelResultEquals);
            this.panelResultSubtask3.Controls.Add(this.label14);
            this.panelResultSubtask3.Location = new System.Drawing.Point(233, 14);
            this.panelResultSubtask3.Name = "panelResultSubtask3";
            this.panelResultSubtask3.Size = new System.Drawing.Size(395, 125);
            this.panelResultSubtask3.TabIndex = 7;
            // 
            // labelResultEquals
            // 
            this.labelResultEquals.AutoSize = true;
            this.labelResultEquals.Location = new System.Drawing.Point(3, 34);
            this.labelResultEquals.Name = "labelResultEquals";
            this.labelResultEquals.Size = new System.Drawing.Size(76, 28);
            this.labelResultEquals.TabIndex = 1;
            this.labelResultEquals.Text = "label15";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 28);
            this.label14.TabIndex = 0;
            this.label14.Text = "Результат:";
            // 
            // buttonСalculation3
            // 
            this.buttonСalculation3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonСalculation3.Location = new System.Drawing.Point(7, 125);
            this.buttonСalculation3.Name = "buttonСalculation3";
            this.buttonСalculation3.Size = new System.Drawing.Size(139, 43);
            this.buttonСalculation3.TabIndex = 6;
            this.buttonСalculation3.Text = "Сравнить";
            this.buttonСalculation3.UseVisualStyleBackColor = false;
            this.buttonСalculation3.Click += new System.EventHandler(this.buttonСalculation3_Click);
            // 
            // textBoxNumber2
            // 
            this.textBoxNumber2.Location = new System.Drawing.Point(102, 85);
            this.textBoxNumber2.Name = "textBoxNumber2";
            this.textBoxNumber2.Size = new System.Drawing.Size(125, 34);
            this.textBoxNumber2.TabIndex = 5;
            // 
            // textBoxNumber1
            // 
            this.textBoxNumber1.Location = new System.Drawing.Point(102, 45);
            this.textBoxNumber1.Name = "textBoxNumber1";
            this.textBoxNumber1.Size = new System.Drawing.Size(125, 34);
            this.textBoxNumber1.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 82);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(89, 28);
            this.label13.TabIndex = 2;
            this.label13.Text = "Число 2:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 42);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 28);
            this.label12.TabIndex = 1;
            this.label12.Text = "Число 1:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 14);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(163, 28);
            this.label11.TabIndex = 0;
            this.label11.Text = "Введите 2 числа:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.labelResultTime);
            this.tabPage4.Controls.Add(this.textBoxTime);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.buttonResultSubtask4);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(634, 321);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Задание 4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // labelResultTime
            // 
            this.labelResultTime.AutoSize = true;
            this.labelResultTime.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelResultTime.Location = new System.Drawing.Point(7, 99);
            this.labelResultTime.Name = "labelResultTime";
            this.labelResultTime.Size = new System.Drawing.Size(76, 28);
            this.labelResultTime.TabIndex = 3;
            this.labelResultTime.Text = "label16";
            // 
            // textBoxTime
            // 
            this.textBoxTime.Location = new System.Drawing.Point(217, 7);
            this.textBoxTime.Name = "textBoxTime";
            this.textBoxTime.Size = new System.Drawing.Size(125, 27);
            this.textBoxTime.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(6, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(205, 28);
            this.label15.TabIndex = 1;
            this.label15.Text = "Введите время суток:";
            // 
            // buttonResultSubtask4
            // 
            this.buttonResultSubtask4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.buttonResultSubtask4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonResultSubtask4.Location = new System.Drawing.Point(7, 43);
            this.buttonResultSubtask4.Name = "buttonResultSubtask4";
            this.buttonResultSubtask4.Size = new System.Drawing.Size(139, 43);
            this.buttonResultSubtask4.TabIndex = 0;
            this.buttonResultSubtask4.Text = "Узнать";
            this.buttonResultSubtask4.UseVisualStyleBackColor = false;
            this.buttonResultSubtask4.Click += new System.EventHandler(this.buttonResultSubtask4_Click);
            // 
            // Task1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(646, 356);
            this.Controls.Add(this.tabControl1);
            this.Name = "Task1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Task1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panelResultSubtask1.ResumeLayout(false);
            this.panelResultSubtask1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panelResultSubtask2.ResumeLayout(false);
            this.panelResultSubtask2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panelResultSubtask3.ResumeLayout(false);
            this.panelResultSubtask3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private PictureBox pictureBox1;
        private TextBox textBoxY;
        private TextBox textBoxZ;
        private TextBox textBoxX;
        private Button buttonСalculation1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Panel panelResultSubtask1;
        private Label labelResultB;
        private Label label7;
        private Label labelResultA;
        private TextBox textBoxX3Y3;
        private Label label9;
        private TextBox textBoxX2Y2;
        private Label label8;
        private TextBox textBoxX1Y1;
        private Label label6;
        private Label label5;
        private Label label10;
        private Panel panelResultSubtask2;
        private Button buttonСalculation;
        private Label labelResultRadius;
        private Button buttonСalculation3;
        private TextBox textBoxNumber2;
        private TextBox textBoxNumber1;
        private Label label13;
        private Label label12;
        private Label label11;
        private Panel panelResultSubtask3;
        private Label labelResultEquals;
        private Label label14;
        private Button buttonResultSubtask4;
        private Label labelResultTime;
        private TextBox textBoxTime;
        private Label label15;
    }
}
﻿namespace lab4_winform.Add
{
    partial class CargoPlane
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAddCargoPlane = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxMaxSpeed = new System.Windows.Forms.TextBox();
            this.labelMaxSpeed = new System.Windows.Forms.Label();
            this.textBoxMaxWeight = new System.Windows.Forms.TextBox();
            this.labelMaxWeight = new System.Windows.Forms.Label();
            this.textBoxLength = new System.Windows.Forms.TextBox();
            this.labelLenght = new System.Windows.Forms.Label();
            this.textBoxCrew = new System.Windows.Forms.TextBox();
            this.labelCrew = new System.Windows.Forms.Label();
            this.textBoxModule = new System.Windows.Forms.TextBox();
            this.labelModule = new System.Windows.Forms.Label();
            this.textBoxLengthWing = new System.Windows.Forms.TextBox();
            this.labelLengthWing = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonAddCargoPlane
            // 
            this.buttonAddCargoPlane.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonAddCargoPlane.Location = new System.Drawing.Point(28, 357);
            this.buttonAddCargoPlane.Name = "buttonAddCargoPlane";
            this.buttonAddCargoPlane.Size = new System.Drawing.Size(140, 52);
            this.buttonAddCargoPlane.TabIndex = 35;
            this.buttonAddCargoPlane.Text = "Добавить";
            this.buttonAddCargoPlane.UseVisualStyleBackColor = true;
            this.buttonAddCargoPlane.Click += new System.EventHandler(this.buttonAddCargoPlane_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 38);
            this.label1.TabIndex = 34;
            this.label1.Text = "Грузовой самолет";
            // 
            // textBoxMaxSpeed
            // 
            this.textBoxMaxSpeed.Location = new System.Drawing.Point(220, 250);
            this.textBoxMaxSpeed.Name = "textBoxMaxSpeed";
            this.textBoxMaxSpeed.Size = new System.Drawing.Size(125, 27);
            this.textBoxMaxSpeed.TabIndex = 33;
            // 
            // labelMaxSpeed
            // 
            this.labelMaxSpeed.AutoSize = true;
            this.labelMaxSpeed.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelMaxSpeed.Location = new System.Drawing.Point(28, 250);
            this.labelMaxSpeed.Name = "labelMaxSpeed";
            this.labelMaxSpeed.Size = new System.Drawing.Size(141, 28);
            this.labelMaxSpeed.TabIndex = 32;
            this.labelMaxSpeed.Text = "Мак. скорость";
            // 
            // textBoxMaxWeight
            // 
            this.textBoxMaxWeight.Location = new System.Drawing.Point(220, 202);
            this.textBoxMaxWeight.Name = "textBoxMaxWeight";
            this.textBoxMaxWeight.Size = new System.Drawing.Size(125, 27);
            this.textBoxMaxWeight.TabIndex = 31;
            // 
            // labelMaxWeight
            // 
            this.labelMaxWeight.AutoSize = true;
            this.labelMaxWeight.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelMaxWeight.Location = new System.Drawing.Point(28, 201);
            this.labelMaxWeight.Name = "labelMaxWeight";
            this.labelMaxWeight.Size = new System.Drawing.Size(186, 28);
            this.labelMaxWeight.TabIndex = 30;
            this.labelMaxWeight.Text = "Грузоподъемность";
            // 
            // textBoxLength
            // 
            this.textBoxLength.Location = new System.Drawing.Point(220, 156);
            this.textBoxLength.Name = "textBoxLength";
            this.textBoxLength.Size = new System.Drawing.Size(125, 27);
            this.textBoxLength.TabIndex = 29;
            // 
            // labelLenght
            // 
            this.labelLenght.AutoSize = true;
            this.labelLenght.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelLenght.Location = new System.Drawing.Point(28, 152);
            this.labelLenght.Name = "labelLenght";
            this.labelLenght.Size = new System.Drawing.Size(71, 28);
            this.labelLenght.TabIndex = 28;
            this.labelLenght.Text = "Длина";
            // 
            // textBoxCrew
            // 
            this.textBoxCrew.Location = new System.Drawing.Point(220, 109);
            this.textBoxCrew.Name = "textBoxCrew";
            this.textBoxCrew.Size = new System.Drawing.Size(125, 27);
            this.textBoxCrew.TabIndex = 27;
            // 
            // labelCrew
            // 
            this.labelCrew.AutoSize = true;
            this.labelCrew.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelCrew.Location = new System.Drawing.Point(28, 105);
            this.labelCrew.Name = "labelCrew";
            this.labelCrew.Size = new System.Drawing.Size(83, 28);
            this.labelCrew.TabIndex = 26;
            this.labelCrew.Text = "Экипаж";
            // 
            // textBoxModule
            // 
            this.textBoxModule.Location = new System.Drawing.Point(220, 65);
            this.textBoxModule.Name = "textBoxModule";
            this.textBoxModule.Size = new System.Drawing.Size(125, 27);
            this.textBoxModule.TabIndex = 25;
            // 
            // labelModule
            // 
            this.labelModule.AutoSize = true;
            this.labelModule.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelModule.Location = new System.Drawing.Point(28, 61);
            this.labelModule.Name = "labelModule";
            this.labelModule.Size = new System.Drawing.Size(84, 28);
            this.labelModule.TabIndex = 24;
            this.labelModule.Text = "Модель";
            // 
            // textBoxLengthWing
            // 
            this.textBoxLengthWing.Location = new System.Drawing.Point(220, 301);
            this.textBoxLengthWing.Name = "textBoxLengthWing";
            this.textBoxLengthWing.Size = new System.Drawing.Size(125, 27);
            this.textBoxLengthWing.TabIndex = 37;
            // 
            // labelLengthWing
            // 
            this.labelLengthWing.AutoSize = true;
            this.labelLengthWing.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelLengthWing.Location = new System.Drawing.Point(28, 301);
            this.labelLengthWing.Name = "labelLengthWing";
            this.labelLengthWing.Size = new System.Drawing.Size(133, 28);
            this.labelLengthWing.TabIndex = 36;
            this.labelLengthWing.Text = "Длина крыла";
            // 
            // CargoPlane
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(378, 426);
            this.Controls.Add(this.textBoxLengthWing);
            this.Controls.Add(this.labelLengthWing);
            this.Controls.Add(this.buttonAddCargoPlane);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxMaxSpeed);
            this.Controls.Add(this.labelMaxSpeed);
            this.Controls.Add(this.textBoxMaxWeight);
            this.Controls.Add(this.labelMaxWeight);
            this.Controls.Add(this.textBoxLength);
            this.Controls.Add(this.labelLenght);
            this.Controls.Add(this.textBoxCrew);
            this.Controls.Add(this.labelCrew);
            this.Controls.Add(this.textBoxModule);
            this.Controls.Add(this.labelModule);
            this.Name = "CargoPlane";
            this.Text = "CargoPlane";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonAddCargoPlane;
        private Label label1;
        private TextBox textBoxMaxSpeed;
        private Label labelMaxSpeed;
        private TextBox textBoxMaxWeight;
        private Label labelMaxWeight;
        private TextBox textBoxLength;
        private Label labelLenght;
        private TextBox textBoxCrew;
        private Label labelCrew;
        private TextBox textBoxModule;
        private Label labelModule;
        private TextBox textBoxLengthWing;
        private Label labelLengthWing;
    }
}